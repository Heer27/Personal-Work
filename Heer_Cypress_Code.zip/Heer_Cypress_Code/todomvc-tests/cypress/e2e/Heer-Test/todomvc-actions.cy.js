import { TodoPage } from "../../page-objects/todo-page";

describe('todo actions', ()=>{
    const todoPage = new TodoPage()

    beforeEach(() =>{
        // cy.visit('http://todomvc-app-for-testing.surge.sh/')
    
        todoPage.navigate()

        todoPage.addTodo('Clean Room')

        // cy.get('.new-todo').type('Clean Room{enter}')
    })

    it('Should add a new todo to the list', () => {
    
        // cy.get('label').should('have.text', 'Clean Room')
        todoPage.validateTodoText(0, 'Clean Room')

        cy.get('.toggle').should('not.be.checked')
        
    })
    
    it('should mark a todo as complete', () => {
        cy.get('.toggle').click()
    
        cy.get('label').should('have.css', 'text-decoration-line', 'line-through')
    })
    
    it('should clear completed todo', () => {
        cy.get('.toggle').click()
        cy.contains('Clear').click()
    
        cy.get('.todo-list').should('not.have.descendants', 'li')
    })
})